import React from 'react';
import { X, LayoutDashboard, Users, Calendar, FileText, MessageSquare, Settings, HelpCircle } from 'lucide-react';

interface SideMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const menuItems = [
  { icon: LayoutDashboard, text: 'Panel Principal', href: '#' },
  { icon: Users, text: 'Colaboradores', href: '#' },
  { icon: Calendar, text: 'Talleres Virtuales', href: '#' },
  { icon: FileText, text: 'Acuerdos', href: '#' },
  { icon: MessageSquare, text: 'Encuestas', href: '#' },
  { icon: Settings, text: 'Configuración', href: '#' },
  { icon: HelpCircle, text: 'Ayuda', href: '#' },
];

export default function SideMenu({ isOpen, onClose }: SideMenuProps) {
  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-gray-600 bg-opacity-50 z-40 transition-opacity"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 w-64 bg-white shadow-xl z-50 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="h-full flex flex-col">
          <div className="h-16 flex items-center justify-between px-4 border-b border-gray-200">
            <span className="text-xl font-bold text-blue-600">Menú</span>
            <button
              onClick={onClose}
              className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100"
              aria-label="Cerrar menú"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          <nav className="flex-1 px-2 py-4 space-y-1">
            {menuItems.map((item) => (
              <a
                key={item.text}
                href={item.href}
                className="flex items-center px-4 py-3 text-gray-700 rounded-md hover:bg-blue-50 hover:text-blue-700 transition-colors duration-200"
              >
                <item.icon className="h-5 w-5 mr-3" />
                <span>{item.text}</span>
              </a>
            ))}
          </nav>
        </div>
      </div>
    </>
  );
}