import React, { useState, useEffect } from 'react';
import { CheckCircle } from 'lucide-react';

interface ToastProps {
  message: string;
  onClose: () => void;
}

const Toast = ({ message, onClose }: ToastProps) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed bottom-4 right-4 flex items-center bg-green-600 text-white px-4 py-2 rounded-lg shadow-lg">
      <CheckCircle className="h-5 w-5 mr-2" />
      <span>{message}</span>
    </div>
  );
};

export function Toaster() {
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    window.addEventListener('show-toast', ((e: CustomEvent) => {
      setToast(e.detail.message);
    }) as EventListener);

    return () => {
      window.removeEventListener('show-toast', ((e: CustomEvent) => {
        setToast(e.detail.message);
      }) as EventListener);
    };
  }, []);

  return toast ? (
    <Toast message={toast} onClose={() => setToast(null)} />
  ) : null;
}