import React, { useState } from 'react';
import { Menu, Bell, User, Search, Download } from 'lucide-react';
import SideMenu from './SideMenu';
import { downloadBetaInfo } from '../utils/downloadHelper';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [notifications] = useState(3);
  const [showDownloadTooltip, setShowDownloadTooltip] = useState(false);

  return (
    <>
      <nav className="bg-white border-b border-gray-200 fixed w-full z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <button 
                onClick={() => setIsMenuOpen(true)}
                className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                aria-label="Abrir menú"
              >
                <Menu className="h-6 w-6" />
              </button>
              <div className="ml-4 flex items-center">
                <span className="text-2xl font-bold text-blue-600">ColaborAPP</span>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="relative mx-4">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-gray-50 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Buscar proyectos..."
                />
              </div>
              
              <div className="relative">
                <button 
                  className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 relative"
                  onMouseEnter={() => setShowDownloadTooltip(true)}
                  onMouseLeave={() => setShowDownloadTooltip(false)}
                  onClick={downloadBetaInfo}
                >
                  <Download className="h-6 w-6" />
                  {showDownloadTooltip && (
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-1 text-sm text-white bg-gray-900 rounded-md whitespace-nowrap">
                      Descargar Beta
                    </div>
                  )}
                </button>
              </div>

              <div className="relative">
                <button className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100">
                  <Bell className="h-6 w-6" />
                  {notifications > 0 && (
                    <span className="absolute top-0 right-0 block h-5 w-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
                      {notifications}
                    </span>
                  )}
                </button>
              </div>
              <button className="ml-3 p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100">
                <User className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      </nav>
      
      <SideMenu isOpen={isMenuOpen} onClose={() => setIsMenuOpen(false)} />
    </>
  );
}