import React from 'react';
import { BarChart3, Users, Calendar, ArrowUpRight, Target, ChevronRight } from 'lucide-react';

const metrics = [
  { name: 'Proyectos Activos', value: '12', change: '+2.5%', icon: Target },
  { name: 'Colaboradores', value: '24', change: '+12%', icon: Users },
  { name: 'Talleres Próximos', value: '8', change: '+4', icon: Calendar },
  { name: 'Crecimiento', value: '7.5%', change: '+2.1%', icon: BarChart3 },
];

const workshops = [
  { id: 1, title: 'Innovación Digital', date: 'Mañana a las 14:00', status: 'Próximo' },
  { id: 2, title: 'Estrategias de Co-creación', date: 'Jueves a las 10:00', status: 'Abierto' },
  { id: 3, title: 'Transformación Digital', date: 'Viernes a las 15:30', status: 'Lleno' },
];

const projects = [
  { id: 1, name: 'Proyecto Estratégico 1', progress: 75 },
  { id: 2, name: 'Innovación Colaborativa', progress: 45 },
  { id: 3, name: 'Transformación Digital', progress: 90 },
];

export default function Dashboard() {
  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-semibold text-gray-900">Panel Principal</h1>
        
        <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {metrics.map((metric) => (
            <div key={metric.name} className="bg-white overflow-hidden shadow rounded-lg hover:shadow-lg transition-shadow duration-300">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <metric.icon className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">{metric.name}</dt>
                      <dd className="flex items-baseline">
                        <div className="text-2xl font-semibold text-gray-900">{metric.value}</div>
                        <div className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                          {metric.change}
                          <ArrowUpRight className="h-4 w-4" />
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium text-gray-900">Talleres Próximos</h2>
              <button className="text-sm text-blue-600 hover:text-blue-800 flex items-center">
                Ver todos
                <ChevronRight className="h-4 w-4 ml-1" />
              </button>
            </div>
            <div className="space-y-4">
              {workshops.map((workshop) => (
                <div key={workshop.id} className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                  <Calendar className="h-10 w-10 text-blue-600" />
                  <div className="ml-4 flex-1">
                    <h3 className="text-sm font-medium text-gray-900">{workshop.title}</h3>
                    <p className="text-sm text-gray-500">{workshop.date}</p>
                  </div>
                  <button className="ml-4 bg-blue-600 text-white px-4 py-2 rounded-md text-sm hover:bg-blue-700 transition-colors duration-200">
                    Unirse
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium text-gray-900">Proyectos Activos</h2>
              <button className="text-sm text-blue-600 hover:text-blue-800 flex items-center">
                Ver todos
                <ChevronRight className="h-4 w-4 ml-1" />
              </button>
            </div>
            <div className="space-y-4">
              {projects.map((project) => (
                <div key={project.id} className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                  <Target className="h-10 w-10 text-blue-600" />
                  <div className="ml-4 flex-1">
                    <h3 className="text-sm font-medium text-gray-900">{project.name}</h3>
                    <div className="mt-1 flex items-center">
                      <div className="w-48 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                          style={{ width: `${project.progress}%` }}
                        />
                      </div>
                      <span className="ml-2 text-sm text-gray-500">{project.progress}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}