export const downloadBetaInfo = () => {
  const betaInfo = {
    nombre: 'ColaborAPP',
    version: '0.1.0-beta',
    fechaLanzamiento: new Date().toLocaleDateString('es-ES'),
    requisitos: {
      navegador: 'Chrome 80+, Firefox 75+, Safari 13+, Edge 80+',
      conexion: 'Banda ancha (mínimo 5Mbps)',
      dispositivo: 'PC, Tablet o Móvil con navegador moderno'
    },
    caracteristicas: [
      'Panel de control interactivo con métricas en tiempo real',
      'Gestión de talleres virtuales y videoconferencias',
      'Seguimiento de proyectos colaborativos',
      'Sistema de notificaciones integrado',
      'Encuestas interactivas y generación de informes',
      'Gestión de acuerdos y responsabilidades',
      'Interfaz multiidioma (Español/Inglés)'
    ],
    instrucciones: {
      acceso: 'Abrir el enlace proporcionado en el navegador web',
      inicio: 'Usar credenciales proporcionadas por el administrador',
      soporte: 'soporte@colaborapp.com'
    }
  };

  const blob = new Blob([JSON.stringify(betaInfo, null, 2)], { type: 'application/json' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'colaborapp-beta-info.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);

  // Mostrar notificación de descarga exitosa
  window.dispatchEvent(new CustomEvent('show-toast', {
    detail: { message: 'Información de la beta descargada exitosamente' }
  }));
};