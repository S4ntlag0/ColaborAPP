import React from 'react';
import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import { Toaster } from './components/Toaster';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <main className="pt-16">
        <Dashboard />
      </main>
      <Toaster />
    </div>
  );
}

export default App;